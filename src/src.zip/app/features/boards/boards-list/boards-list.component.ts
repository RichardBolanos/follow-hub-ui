import { Routes } from '@angular/router';
import { BoardsListComponent } from './boards-list.component';

export const routes: Routes = [
  { path: '', component: BoardsListComponent }
];
