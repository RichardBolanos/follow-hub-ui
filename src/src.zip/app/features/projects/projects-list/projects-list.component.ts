import { Component } from '@angular/core';

@Component({
  selector: 'app-projects-list',
  imports: [],
  templateUrl: './projects-list.component.html',
  styleUrl: './projects-list.component.scss'
})
export class ProjectsListComponent {

}
